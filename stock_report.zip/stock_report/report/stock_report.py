# -*- coding: utf-8 -*-
from odoo import models, api


class StockReport(models.AbstractModel):
    _name = 'report.stock_report.product_stock_report'

    @api.model
    def _get_report_values(self,  docids, data=None):
        query = """select st.product_id , st.quantity, pt.list_price, pt.name ->> 'en_US' as product, pt.default_code from stock_quant as st
                   inner join product_product as pr on pr.id = st.product_id
                   inner join product_template as pt on pt.id = pr.product_tmpl_id"""

        self.env.cr.execute(query)
        report = self.env.cr.dictfetchall()
        print("report",report)
        return {
            'docs': report,
            'data': data,
        }
