# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    sale_order_ids = fields.One2many('sale.order', inverse_name='partner_id', string='Sale order')
    product_count = fields.Integer(compute='_product_count',string="Product Count")

    def action_total_product(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'product.product',
            'view_mode': 'tree,form',
            'domain': [('sale_ok', '=', True)],
            'context': "{'create': False}"
        }

    def _product_count(self):
        """ calculating the product count"""
        for record in self:
            record.product_count = self.env['product.product'].search_count(
                [('sale_ok', '=', True)])