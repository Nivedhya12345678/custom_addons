# -*- coding: utf-8 -*-
from . import disable_delivery
